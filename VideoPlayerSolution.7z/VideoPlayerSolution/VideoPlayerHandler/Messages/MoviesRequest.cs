﻿namespace VideoPlayer.Handlers.Messages
{
    public class MoviesRequest
    {
    }
}
